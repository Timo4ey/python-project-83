### Hexlet tests and linter status:
[![Actions Status](https://github.com/Timo4ey/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Timo4ey/python-project-83/actions)

![Actions Status](https://github.com/Timo4ey/python-project-83/actions/workflows/my-checker.yml/badge.svg)

[![Maintainability](https://api.codeclimate.com/v1/badges/6570fc9e3f3cfee9f2b8/maintainability)](https://codeclimate.com/github/Timo4ey/python-project-83/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/6570fc9e3f3cfee9f2b8/test_coverage)](https://codeclimate.com/github/Timo4ey/python-project-83/test_coverage)

site: https://python-project-83-production-e006.up.railway.app/
