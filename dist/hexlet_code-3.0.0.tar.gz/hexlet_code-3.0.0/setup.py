# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer',
 'page_analyzer.config',
 'page_analyzer.db',
 'page_analyzer.link_validator',
 'page_analyzer.models',
 'page_analyzer.url_handler']

package_data = \
{'': ['*'], 'page_analyzer': ['templates/*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'flask>=2.2.2,<3.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'lxml>=4.9.2,<5.0.0',
 'psycopg2-binary>=2.9.5,<3.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'requests>=2.28.2,<3.0.0',
 'validators>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '3.0.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Timo4ey/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Timo4ey/python-project-83/actions)\n\n![Actions Status](https://github.com/Timo4ey/python-project-83/actions/workflows/my-checker.yml/badge.svg)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/6570fc9e3f3cfee9f2b8/maintainability)](https://codeclimate.com/github/Timo4ey/python-project-83/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/6570fc9e3f3cfee9f2b8/test_coverage)](https://codeclimate.com/github/Timo4ey/python-project-83/test_coverage)\n\nsite: https://python-project-83-production-e006.up.railway.app/\n',
    'author': 'Timofey',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
