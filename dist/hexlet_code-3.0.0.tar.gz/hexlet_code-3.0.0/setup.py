# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer',
 'page_analyzer.config',
 'page_analyzer.db',
 'page_analyzer.link_validator',
 'page_analyzer.models',
 'page_analyzer.url_handler']

package_data = \
{'': ['*'], 'page_analyzer': ['templates/*']}

install_requires = \
['beautifulsoup4>=4.12.1,<5.0.0',
 'bootstrap-flask>=2.2.0,<3.0.0',
 'coverage>=7.2.2,<8.0.0',
 'flake8>=6.0.0,<7.0.0',
 'flask-session>=0.4.0,<0.5.0',
 'flask-wtf>=1.1.1,<2.0.0',
 'flask>=2.2.3,<3.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'libsass>=0.22.0,<0.23.0',
 'pipenv>=2023.3.20,<2024.0.0',
 'psycopg2-binary>=2.9.6,<3.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'pytest>=7.2.2,<8.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'requests>=2.28.2,<3.0.0',
 'validators>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '3.0.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Timo4ey/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/Timo4ey/python-project-83/actions)\n\n![Actions Status](https://github.com/Timo4ey/python-project-83/actions/workflows/my-checker.yml/badge.svg)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/6570fc9e3f3cfee9f2b8/maintainability)](https://codeclimate.com/github/Timo4ey/python-project-83/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/6570fc9e3f3cfee9f2b8/test_coverage)](https://codeclimate.com/github/Timo4ey/python-project-83/test_coverage)\n\nsite: https://python-project-83-production-e006.up.railway.app/\n',
    'author': 'Timofey',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4',
}


setup(**setup_kwargs)
