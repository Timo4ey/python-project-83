from .models import Urls, UrlChecks


__all__ = ['Urls', 'UrlChecks']
